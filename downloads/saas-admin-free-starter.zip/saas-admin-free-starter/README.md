Static Free Starter. No backend or paid services included.
